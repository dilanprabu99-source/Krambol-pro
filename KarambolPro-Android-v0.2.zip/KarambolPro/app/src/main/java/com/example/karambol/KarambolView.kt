package com.example.karambol

import android.content.Context
import android.graphics.*
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

private data class P(var x:Float,var y:Float,var vx:Float=0f,var vy:Float=0f,val color:Int,var queen:Boolean=false,var pocketed:Boolean=false)

class KarambolView(ctx:Context):View(ctx){
    private val handler=Handler(Looper.getMainLooper()); private val tone=ToneGenerator(AudioManager.STREAM_MUSIC,70)
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG); private val label=Paint(Paint.ANTI_ALIAS_FLAG)
    private var L=0f;private var T=0f;private var R=0f;private var B=0f;private var S=0f;private var cx=0f;private var cy=0f
    private val pieces=mutableListOf<P>(); private lateinit var striker:P
    private var aiming=false; private var ax=0f;private var ay=0f; private var player=true;private var busy=false
    private var score=0;private var cpu=0;private var status="Tarik striker untuk membidik";private var winner=false
    private val pockets=arrayOf(floatArrayOf(0f,0f),floatArrayOf(0f,0f),floatArrayOf(0f,0f),floatArrayOf(0f,0f))
    init{label.typeface=Typeface.create(Typeface.DEFAULT,Typeface.BOLD);setBackgroundColor(Color.rgb(18,18,18))}
    override fun onSizeChanged(w:Int,h:Int,ow:Int,oh:Int){S=min(h*.86f,w*.78f);L=(w-S)/2;T=(h-S)/2;R=L+S;B=T+S;cx=(L+R)/2;cy=(T+B)/2;reset()}
    private fun reset(){pieces.clear();val ring=S*.075f;repeat(12){i->val a=i*PI*2/12;pieces.add(P(cx+cos(a).toFloat()*ring,cy+sin(a).toFloat()*ring,color=if(i%3==0)Color.rgb(35,35,35) else Color.rgb(240,240,232),queen=i==0))};striker=P(cx,B-S*.115f,color=Color.rgb(246,246,246));score=0;cpu=0;player=true;busy=false;winner=false;status="Tarik striker untuk membidik";invalidate()}
    override fun onDraw(c:Canvas){super.onDraw(c)
        // wood frame + subtle grain
        paint.style=Paint.Style.FILL;paint.color=Color.rgb(92,52,25);c.drawRoundRect(L-32,T-32,R+32,B+32,28f,28f,paint)
        paint.color=Color.rgb(166,107,55);c.drawRoundRect(L-18,T-18,R+18,B+18,20f,20f,paint)
        paint.color=Color.rgb(235,207,158);c.drawRect(L,T,R,B,paint)
        paint.color=Color.argb(25,80,50,20); for(i in 0..28)c.drawRect(L,T+i*S/28,R,T+i*S/28+2,paint)
        val inset=S*.065f; paint.style=Paint.Style.STROKE;paint.strokeWidth=3f;paint.color=Color.rgb(95,52,23);c.drawRect(L+inset,T+inset,R-inset,B-inset,paint)
        // guide lines and baseline circles
        paint.strokeWidth=2f;c.drawLine(L+S*.16f,B-S*.115f,R-S*.16f,B-S*.115f,paint);c.drawLine(L+S*.16f,T+S*.115f,R-S*.16f,T+S*.115f,paint)
        paint.style=Paint.Style.FILL
        val pr=S*.055f; pockets[0][0]=L;pockets[0][1]=T;pockets[1][0]=R;pockets[1][1]=T;pockets[2][0]=L;pockets[2][1]=B;pockets[3][0]=R;pockets[3][1]=B
        for(q in pockets){paint.color=Color.rgb(20,14,10);c.drawCircle(q[0],q[1],pr,paint);paint.color=Color.argb(90,255,255,255);c.drawCircle(q[0]-pr*.18f,q[1]-pr*.18f,pr*.18f,paint)}
        paint.style=Paint.Style.STROKE;paint.strokeWidth=3f;paint.color=Color.rgb(120,70,30);c.drawCircle(cx,cy,S*.105f,paint);c.drawCircle(cx,cy,S*.028f,paint)
        for(p in pieces)if(!p.pocketed)drawPiece(c,p,S*.025f);drawPiece(c,striker,S*.035f)
        if(aiming&&!busy){paint.color=Color.argb(140,75,40,15);paint.strokeWidth=5f;c.drawLine(striker.x,striker.y,ax,ay,paint);paint.strokeWidth=2f; c.drawCircle(ax,ay,10f,paint)}
        label.color=Color.WHITE;label.textSize=30f;c.drawText("KARAMBOL PRO",28f,42f,label);label.textSize=22f;c.drawText("Kamu  $score",28f,75f,label);c.drawText("CPU  $cpu",28f,105f,label)
        label.textSize=22f;val tw=label.measureText(status);c.drawText(status,(width-tw)/2,height-24f,label)
        label.textSize=17f;label.color=Color.LTGRAY;c.drawText("Tarik berlawanan arah pukulan • lepas untuk menembak",width-430f,34f,label)
    }
    private fun drawPiece(c:Canvas,p:P,r:Float){paint.style=Paint.Style.FILL;paint.color=Color.argb(55,0,0,0);c.drawCircle(p.x+3,p.y+4,r*1.08f,paint);paint.color=p.color;c.drawCircle(p.x,p.y,r,paint);paint.style=Paint.Style.STROKE;paint.strokeWidth=1.5f;paint.color=Color.DKGRAY;c.drawCircle(p.x,p.y,r,paint);if(p.queen){paint.color=Color.rgb(190,35,35);paint.strokeWidth=3f;c.drawCircle(p.x,p.y,r*.43f,paint)}}
    override fun onTouchEvent(e:MotionEvent):Boolean{if(winner){if(e.action==MotionEvent.ACTION_UP)reset();return true};if(!player||busy)return true
        when(e.action){MotionEvent.ACTION_DOWN->{if(d(striker.x,striker.y,e.x,e.y)<S*.07f){aiming=true;ax=e.x;ay=e.y;invalidate()}};MotionEvent.ACTION_MOVE->if(aiming){ax=e.x;ay=e.y;invalidate()};MotionEvent.ACTION_UP->if(aiming){aiming=false;val dx=striker.x-ax;val dy=striker.y-ay;val len=hypot(dx,dy);if(len>12){striker.vx=dx/len*min(S*.014f*14,len*.055f);striker.vy=dy/len*min(S*.014f*14,len*.055f);busy=true;status="Pukulan...";tone.startTone(ToneGenerator.TONE_PROP_BEEP,45);simulate(true)}}};return true}
    private fun simulate(isPlayer:Boolean){var frames=0;while(frames++<1000){var moving=false;val all=ArrayList<P>();all.addAll(pieces);all.add(striker);for(p in all)if(!p.pocketed){p.x+=p.vx;p.y+=p.vy;p.vx*=.988f;p.vy*=.988f;if(abs(p.vx)+abs(p.vy)>.035f)moving=true else{p.vx=0f;p.vy=0f};val minx=L+S*.065f;val maxx=R-S*.065f;val miny=T+S*.065f;val maxy=B-S*.065f;if(p.x<minx){p.x=minx;p.vx=abs(p.vx)};if(p.x>maxx){p.x=maxx;p.vx=-abs(p.vx)};if(p.y<miny){p.y=miny;p.vy=abs(p.vy)};if(p.y>maxy){p.y=maxy;p.vy=-abs(p.vy)}}
            for(i in 0 until all.size)for(j in i+1 until all.size){val a=all[i];val b=all[j];if(a.pocketed||b.pocketed)continue;val dx=b.x-a.x;val dy=b.y-a.y;val dd=hypot(dx,dy);val md=S*.049f;if(dd>0&&dd<md){val nx=dx/dd;val ny=dy/dd;val rel=(b.vx-a.vx)*nx+(b.vy-a.vy)*ny;if(rel<0){a.vx-=rel*nx;a.vy-=rel*ny;b.vx+=rel*nx;b.vy+=rel*ny;if(abs(rel)>.35f)tone.startTone(ToneGenerator.TONE_PROP_BEEP,20)}}}
            for(p in all)if(!p.pocketed){for(q in pockets)if(d(p.x,p.y,q[0],q[1])<S*.052f){p.pocketed=true;p.vx=0f;p.vy=0f;tone.startTone(ToneGenerator.TONE_PROP_ACK,35);if(p===striker){if(isPlayer)score=max(0,score-1)else cpu=max(0,cpu-1)}else{val pts=if(p.queen)3 else 1;if(isPlayer)score+=pts else cpu+=pts}}}
            if(!moving)break
        }
        striker.pocketed=false;striker.x=cx;striker.y=B-S*.115f;striker.vx=0f;striker.vy=0f;invalidate();handler.postDelayed({if(pieces.none{!it.pocketed}){winner=true;status=if(score>cpu)"Kamu menang • tap untuk main lagi" else if(cpu>score)"CPU menang • tap untuk main lagi" else "Seri • tap untuk main lagi";busy=false;invalidate()}else if(isPlayer){player=false;status="CPU membidik...";invalidate();handler.postDelayed({cpuShot()},350)}else{player=true;busy=false;status="Giliran kamu";invalidate()}},180)}
    private fun cpuShot(){val t=pieces.filter{!it.pocketed}.minByOrNull{d(it.x,it.y,striker.x,striker.y)}?:return;val dx=t.x-striker.x;val dy=t.y-striker.y;val len=max(1f,hypot(dx,dy));striker.vx=dx/len*min(S*.15f,len*.025f);striker.vy=dy/len*min(S*.15f,len*.025f);busy=true;simulate(false)}
    private fun d(a:Float,b:Float,c:Float,e:Float)=hypot(a-c,b-e)
}
