# Karambol Pro — Android Prototype v0.2

Prototipe yang ditingkatkan dengan:
- papan bergaya kayu + tekstur halus
- lubang 4 sudut dengan efek kedalaman/highlight
- bidak dengan bayangan dan queen merah
- kontrol tarik-lepas seperti ketapel untuk menentukan arah/kekuatan
- pantulan dinding, gesekan, dan tabrakan bidak
- suara sederhana untuk pukulan, benturan, dan masuk lubang menggunakan ToneGenerator Android
- skor pemain vs CPU
- CPU sederhana
- landscape fullscreen

Buka folder ini di Android Studio dan build `app` untuk membuat APK debug.
